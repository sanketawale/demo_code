'use strict';

/**
 * Resource helper
 *
 */

/**
 * Get the client-side resources of a given page
 * @param {string} pageContext : The page context which need to be render
 * @returns {Object} resources : An objects key key-value pairs holding the resources
 */
function getResources(pageContext) {
    var Resource = require('dw/web/Resource');
    var URLUtils = require('dw/web/URLUtils');

    var resources = {
        FREE_MATERNITYKIT_NOT_ELIGIBLE: Resource.msg('info.free.maternitykit.not', 'product', null),
        FREE_MATERNITYKIT_LOGIN: Resource.msg('info.free.maternitykit.login', 'product', null),
        FREE_MATERNITYKIT: Resource.msg('info.free.maternitykit', 'product', null),
        LOGIN_URL: URLUtils.url('Login-Show').toString()
    };
    return resources;
}

module.exports = {
    getResources: getResources
};
