jQuery(document).ready(function(jQuery) {


    jQuery( window ).scroll(function(){
      if ( jQuery( this ).scrollTop() > 10 ) {
        jQuery( '.site-header' ).addClass( 'sticky-header' );
      } else {
        jQuery( '.site-header' ).removeClass( 'sticky-header' );
      }
    });
  
    /* Banner Slider */
    jQuery('.banner_slider .owl-carousel').owlCarousel({
      loop      : false,
      margin    : 30,
      autoplay  : true,
      nav       : false,
      navText   : ["<span class='fal fa-arrow-left'></span>","<span class='fal fa-arrow-right'></span>"],
      dots      : true,
      responsive:{
          0:{
            items : 1,
          },
          600:{
            items : 1,
          },
          768:{
            items : 1,            
          },
          1000:{
            items : 1,
          },
          1501:{
            items : 1
          }
      }
    });
  
  
    /* Product Slider */
    jQuery('.products_slider .owl-carousel').owlCarousel({
      loop      : false,
      margin    : 30,
      autoplay  : true,
      nav       : true,
      navText   : ["<i class='fa fa-angle-left' aria-hidden='true'></i>","<i class='fa fa-angle-right' aria-hidden='true'></i>"],
      dots      : true,
      responsive:{
        0:{
          items : 1,
        },
        767:{
          items : 2,
        },
        992:{
          items : 3,            
        },
        1200:{
          items : 4,
        },
      }
    });
  
    /* Promotion Slider */
    jQuery('.promotion_slider .owl-carousel').owlCarousel({
      loop      : false,
      margin    : 30,
      autoplay  : true,
      nav       : true,
      navText   : ["<i class='fa fa-angle-left' aria-hidden='true'></i>","<i class='fa fa-angle-right' aria-hidden='true'></i>"],
      dots      : true,
      responsive:{
        0:{
          items : 1,
        },
        767:{
          items : 2,
        },
        992:{
          items : 2,            
        },
        1200:{
          items : 3,
        },
      }
    });
  
    jQuery('.promotion_slider').on('afterChange', function (event, slick, currentSlide) {    
      if(currentSlide === 2) {
        jQuery('.slick-next').addClass('hidden');
      }
      else {
        jQuery('.slick-next').removeClass('hidden');
      }
      if(currentSlide === 0) {
        jQuery('.slick-prev').addClass('hidden');
      }
      else {
        jQuery('.slick-prev').removeClass('hidden');
      }  
    });
  
    
  
  
    /* Match Height */
    jQuery( '.solution-boxes .box h4' ).matchHeight({
      byRow:true
    });
  
    /* Counter */
    jQuery( '.counter' ).counterUp({
      delay: 10,
      time: 2000
    });
  
  
  
    // Action when click on a Heart icon (color)
    jQuery( '.product_box .heart_icon' ).click(function(e) {
      e.preventDefault(); // Modified: stop link # from loading (Why using link then?)
      jQuery( this ).toggleClass( 'selected' ); // Toggle the colored class !
    });
  
  
    // Close Top-bar
    jQuery( '.top-bar .close_data' ).click(function() {
      jQuery( '.top-bar').slideToggle( 'slow' );
    });
  
  
  
    // Footer Menu Collapse
    footer_collapse();
    jQuery(window).resize(function() {
      footer_collapse();
    });
  
  
  });
  
  
  
  // mobile menu open close
  function openNav() {
    document.getElementById("mySidenav").style.left = "0";
  }
  
  function closeNav() {
    document.getElementById("mySidenav").style.left = "-100%";
  }
  
  var windowSize = $(window).width();
  if ( windowSize < 1200 ) {
    $( '#mySidenav .parent-menu' ).on('click', function () {
      $( this ).find( '.sub-menu' ).slideToggle( 'slow' );
    });
  }
  
  
  
  // Footer Menu Collapse
  function footer_collapse() {
    if ( jQuery(window).width() > 767 ) {
      jQuery( '#about' ).addClass( 'show' );
      jQuery( '#support' ).addClass( 'show' );
      jQuery( '#services' ).addClass( 'show' );
      jQuery( '#products' ).addClass( 'show' );
      jQuery( '#call_us' ).addClass( 'show' );
    }
    else {
      jQuery( '#about' ).removeClass( 'show' );
      jQuery( '#support' ).removeClass( 'show' );
      jQuery( '#services' ).removeClass( 'show' );
      jQuery( '#products' ).removeClass( 'show' );
      jQuery( '#call_us' ).removeClass( 'show' );
    }
  }