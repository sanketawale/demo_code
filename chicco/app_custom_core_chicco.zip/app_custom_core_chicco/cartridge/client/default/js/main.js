window.jQuery = window.$ = require('jquery');
var processInclude = require('base/util');
processInclude(require('base/main'));

$(document).ready(function () {
    processInclude(require('./component/freeMaternityKit'));
});

