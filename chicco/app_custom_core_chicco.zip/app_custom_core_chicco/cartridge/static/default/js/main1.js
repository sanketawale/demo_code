jQuery(document).ready(function(jQuery) {


  jQuery( window ).scroll(function(){
    if ( jQuery( this ).scrollTop() > 10 ) {
      jQuery( '.site-header' ).addClass( 'sticky-header' );
    } else {
      jQuery( '.site-header' ).removeClass( 'sticky-header' );
    }
  });

  /* Banner Slider */
  jQuery( '.banner_slider' ).slick({
    slidesToShow    : 1,
    slidesToScroll  : 1,
    autoplay        : true,
    autoplaySpeed   : 7000,
    dots            : true,
    arrows          : false,
    // fade            : true,
  });


  /* Product Slider */
  jQuery( '.products_slider' ).slick({
    infinite        : false,
    slidesToShow    : 4,
    slidesToScroll  : 4,
    autoplay        : true,
    autoplaySpeed   : 7000,
    dots            : true,
    arrows          : true,
    prevArrow       : "<button type='button' class='slick-prev pull-left'><i class='fa fa-angle-left' aria-hidden='true'></i></button>",
    nextArrow       : "<button type='button' class='slick-next pull-right'><i class='fa fa-angle-right' aria-hidden='true'></i></button>",
    responsive: [
      {
        breakpoint: 1199,
        settings: {
          slidesToShow    : 3,
          slidesToScroll  : 3,
          dots            : true,
          arrows          : false,
          prevArrow       : "",
          nextArrow       : "",
        }
      },
      {
        breakpoint: 991,
        settings: {
          slidesToShow    : 2,
          slidesToScroll  : 2,
          dots            : true,
          arrows          : false,
          prevArrow       : "",
          nextArrow       : "",
        }
      },
      {
        breakpoint: 767,
        settings: {
          slidesToShow    : 1,
          slidesToScroll  : 1,
          dots            : true,
          arrows          : false,
          prevArrow       : "",
          nextArrow       : "",
        }
      }
    ]
  });

  jQuery('.products_slider').on('afterChange', function (event, slick, currentSlide) {    
    if(currentSlide === 2) {
      jQuery('.slick-next').addClass('hidden');
    }
    else {
      jQuery('.slick-next').removeClass('hidden');
    }
    if(currentSlide === 0) {
      jQuery('.slick-prev').addClass('hidden');
    }
    else {
      jQuery('.slick-prev').removeClass('hidden');
    }  
  });



  /* Promotion Slider */
  jQuery( '.promotion_slider' ).slick({
    infinite        : false,
    slidesToShow    : 3,
    slidesToScroll  : 3,
    autoplay        : true,
    autoplaySpeed   : 7000,
    dots            : true,
    arrows          : true,
    prevArrow       : "<button type='button' class='slick-prev pull-left'><i class='fa fa-angle-left' aria-hidden='true'></i></button>",
    nextArrow       : "<button type='button' class='slick-next pull-right'><i class='fa fa-angle-right' aria-hidden='true'></i></button>",
    responsive: [
      {
        breakpoint: 1199,
        settings: {
          slidesToShow    : 2,
          slidesToScroll  : 2,
          dots            : true,
          arrows          : false,
          prevArrow       : "",
          nextArrow       : "",
        }
      },
      {
        breakpoint: 991,
        settings: {
          slidesToShow    : 2,
          slidesToScroll  : 2,
          dots            : true,
          arrows          : false,
          prevArrow       : "",
          nextArrow       : "",
        }
      },
      {
        breakpoint: 767,
        settings: {
          slidesToShow    : 1,
          slidesToScroll  : 1,
          dots            : true,
          arrows          : false,
          prevArrow       : "",
          nextArrow       : "",
        }
      }
    ]
  });

  jQuery('.promotion_slider').on('afterChange', function (event, slick, currentSlide) {    
    if(currentSlide === 2) {
      jQuery('.slick-next').addClass('hidden');
    }
    else {
      jQuery('.slick-next').removeClass('hidden');
    }
    if(currentSlide === 0) {
      jQuery('.slick-prev').addClass('hidden');
    }
    else {
      jQuery('.slick-prev').removeClass('hidden');
    }  
  });

  


  /* Match Height */
  jQuery( '.solution-boxes .box h4' ).matchHeight({
    byRow:true
  });

  /* Counter */
  jQuery( '.counter' ).counterUp({
    delay: 10,
    time: 2000
  });



  // Action when click on a Heart icon (color)
  jQuery( '.product_box .heart_icon' ).click(function(e) {
    e.preventDefault(); // Modified: stop link # from loading (Why using link then?)
    jQuery( this ).toggleClass( 'selected' ); // Toggle the colored class !
  });


});



// mobile menu open close
function openNav() {
  document.getElementById("mySidenav").style.left = "0";
}

function closeNav() {
  document.getElementById("mySidenav").style.left = "-100%";
}

var windowSize = $(window).width();
if ( windowSize < 1200 ) {
  $( '#mySidenav .parent-menu' ).on('click', function () {
    $( this ).find( '.sub-menu' ).slideToggle( 'slow' );
  });
}

