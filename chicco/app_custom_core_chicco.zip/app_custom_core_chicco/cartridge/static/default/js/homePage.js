/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./chicco/app_custom_storefront_chicco/cartridge/client/default/js/homePage.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./chicco/app_custom_storefront_chicco/cartridge/client/default/js/homePage.js":
/*!*************************************************************************************!*\
  !*** ./chicco/app_custom_storefront_chicco/cartridge/client/default/js/homePage.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

jQuery(document).ready(function (jQuery) {
  jQuery(window).scroll(function () {
    if (jQuery(this).scrollTop() > 10) {
      jQuery('.site-header').addClass('sticky-header');
    } else {
      jQuery('.site-header').removeClass('sticky-header');
    }
  });
  /* Banner Slider */

  jQuery('.banner_slider .owl-carousel').owlCarousel({
    loop: false,
    margin: 30,
    autoplay: true,
    nav: false,
    navText: ["<span class='fal fa-arrow-left'></span>", "<span class='fal fa-arrow-right'></span>"],
    dots: true,
    responsive: {
      0: {
        items: 1
      },
      600: {
        items: 1
      },
      768: {
        items: 1
      },
      1000: {
        items: 1
      },
      1501: {
        items: 1
      }
    }
  });
  /* Product Slider */

  jQuery('.products_slider .owl-carousel').owlCarousel({
    loop: false,
    margin: 30,
    autoplay: true,
    nav: true,
    navText: ["<i class='fa fa-angle-left' aria-hidden='true'></i>", "<i class='fa fa-angle-right' aria-hidden='true'></i>"],
    dots: true,
    responsive: {
      0: {
        items: 1
      },
      767: {
        items: 2
      },
      992: {
        items: 3
      },
      1200: {
        items: 4
      }
    }
  });
  /* Promotion Slider */

  jQuery('.promotion_slider .owl-carousel').owlCarousel({
    loop: false,
    margin: 30,
    autoplay: true,
    nav: true,
    navText: ["<i class='fa fa-angle-left' aria-hidden='true'></i>", "<i class='fa fa-angle-right' aria-hidden='true'></i>"],
    dots: true,
    responsive: {
      0: {
        items: 1
      },
      767: {
        items: 2
      },
      992: {
        items: 2
      },
      1200: {
        items: 3
      }
    }
  });
  jQuery('.promotion_slider').on('afterChange', function (event, slick, currentSlide) {
    if (currentSlide === 2) {
      jQuery('.slick-next').addClass('hidden');
    } else {
      jQuery('.slick-next').removeClass('hidden');
    }

    if (currentSlide === 0) {
      jQuery('.slick-prev').addClass('hidden');
    } else {
      jQuery('.slick-prev').removeClass('hidden');
    }
  });
  /* Match Height */

  jQuery('.solution-boxes .box h4').matchHeight({
    byRow: true
  });
  /* Counter */

  jQuery('.counter').counterUp({
    delay: 10,
    time: 2000
  }); // Action when click on a Heart icon (color)

  jQuery('.product_box .heart_icon').click(function (e) {
    e.preventDefault(); // Modified: stop link # from loading (Why using link then?)

    jQuery(this).toggleClass('selected'); // Toggle the colored class !
  }); // Close Top-bar

  jQuery('.top-bar .close_data').click(function () {
    jQuery('.top-bar').slideToggle('slow');
  }); // Footer Menu Collapse

  footer_collapse();
  jQuery(window).resize(function () {
    footer_collapse();
  });
}); // mobile menu open close

function openNav() {
  document.getElementById("mySidenav").style.left = "0";
}

function closeNav() {
  document.getElementById("mySidenav").style.left = "-100%";
}

var windowSize = $(window).width();

if (windowSize < 1200) {
  $('#mySidenav .parent-menu').on('click', function () {
    $(this).find('.sub-menu').slideToggle('slow');
  });
} // Footer Menu Collapse


function footer_collapse() {
  if (jQuery(window).width() > 767) {
    jQuery('#about').addClass('show');
    jQuery('#support').addClass('show');
    jQuery('#services').addClass('show');
    jQuery('#products').addClass('show');
    jQuery('#call_us').addClass('show');
  } else {
    jQuery('#about').removeClass('show');
    jQuery('#support').removeClass('show');
    jQuery('#services').removeClass('show');
    jQuery('#products').removeClass('show');
    jQuery('#call_us').removeClass('show');
  }
}

/***/ })

/******/ });
//# sourceMappingURL=homePage.js.map